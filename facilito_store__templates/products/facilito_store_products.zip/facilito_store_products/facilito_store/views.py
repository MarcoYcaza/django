from django.shortcuts import render
from django.shortcuts import redirect

#librerias importantes para autenticar
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth import logout
from django.contrib.auth import authenticate
from django.contrib.auth.models import User

from .forms import RegisterForms

from products.models import Product

#la petición es request
def index(request):
    if request.user.is_authenticated:
    
        products = Product.objects.all().order_by('-id')

        return render(request,'index.html',{
            'mensaje':'Listado de productos',
            'title':'Productos',
            'products':products,
        })
    else:
        return redirect('login')

def login_view(request):
    if request.user.is_authenticated:
        return redirect('index')

    #print(request.method)
    if request.method == 'POST':
        username = request.POST.get('username') #diccionario print(username)
        password = request.POST.get('password') #None   print(password)

        user = authenticate(username=username,password=password) #None

        if user:
            login(request,user)
            messages.success(request,'Bienvenido {}'.format(user.username))
            return redirect('index')
        else:
            messages.error(request,'Usuario o contraseña no válidos')

        #if user:
        #    login(request,user)
        #    print("usuario autenticado")
        #else:
        #    print("Usuario no autenticado")

        
    
    return render(request,'users/login.html',{

    })

def logout_view(request): #El request es lo que recibo de url patterns
        #tengo que revisar que metodo está portando el request}
    
    logout(request)

    messages.success(request,'Sesión cerrada exitosamente')

    return redirect('login')

def register(request):
    if request.user.is_authenticated:
        return redirect('index')

    form = RegisterForms(request.POST or None)

    if request.method == 'POST' and form.is_valid():

        #username = form.cleaned_data.get('username')
        #email = form.cleaned_data.get('email')
        #password = form.cleaned_data.get('password')

        user = form.save()

        if user:
                login(request,user)
                messages.success(request,'Usuario creado exitosamente')
                return redirect('index')

        #user=User.objects.create_user(username,email,password)
        #if user != "duplicidad":
        #    if user:
        #        login(request,user)
        #        messages.success(request,'Usuario creado exitosamente')
        #        return redirect('index')
        #else:
        #    messages.error(request,'Usuario o contraseña no válidos')
            

    return render(request,'users/register.html',{
        'form' : form
    })