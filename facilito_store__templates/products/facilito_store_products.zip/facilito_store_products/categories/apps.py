from django.apps import AppConfig


class CategoriesConfig(AppConfig):
    name = 'categories'
