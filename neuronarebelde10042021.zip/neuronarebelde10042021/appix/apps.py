from django.apps import AppConfig


class AppixConfig(AppConfig):
    name = 'appix'
