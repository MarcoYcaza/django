from django.db import models

# Create your models here.


class Tag(models.Model):
    tagName = models.CharField(max_length=25)

    def __str__(self):
        return self.tagName


class Subject(models.Model):
    subjectName = models.CharField(max_length=25)
    description = models.TextField(default="Write here your answer...")

    def __str__(self):
        return self.subjectName

    def get_absolute_url(self):
        from django.urls import reverse

        return reverse("questpanel", kwargs={"subject": self.subjectName, "pk": 1})


class SimpleCard(models.Model):

    question = models.TextField(blank=False, null=False)
    answer = models.TextField(default="Write here your answer...")
    counter = models.IntegerField(default=0)
    tag = models.ManyToManyField(Tag)
    subject = models.ForeignKey(Subject, default=None, on_delete=models.CASCADE)

    def __str__(self):
        return self.question

    def get_absolute_url(self):
        from django.urls import reverse

        return reverse("questpanel", kwargs={"pk": self.pk})


class ImageCard(models.Model):

    question = models.TextField(blank=False, null=False)
    counter = models.IntegerField(default=0)
    tag = models.ManyToManyField(Tag)
    subject = models.ForeignKey(Subject, default=None, on_delete=models.CASCADE)

    def __str__(self):
        return self.question


class InLineImagexCard(models.Model):
    card = models.ForeignKey(ImageCard, default=None, on_delete=models.CASCADE)
    isAnswer = models.BooleanField(default=False)
    image = models.FileField(blank=True, upload_to="images/")

    def __str__(self):
        return self.card.question


class MultipleChoiceCard(models.Model):

    question = models.TextField(blank=False, null=False)
    counter = models.IntegerField(default=0)
    subject = models.ForeignKey(Subject, default=None, on_delete=models.CASCADE)
    tag = models.ManyToManyField(Tag)

    def __str__(self):
        return self.question


class InLineChoicexCard(models.Model):
    card = models.ForeignKey(MultipleChoiceCard, default=None, on_delete=models.CASCADE)
    choice = models.CharField(max_length=150)
    isAnswer = models.BooleanField(default=False)
    images = models.FileField(blank=True, upload_to="images/")

    def __str__(self):
        return self.card.concept