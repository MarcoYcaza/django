from django.shortcuts import render, redirect
from appix.models import SimpleCard, ImageCard, InLineImagexCard, Subject
import numpy as np
from appix.forms import MyAnswerForm


# Create your views here.
def about(request):
    return render(request, "appix/about.html")


# Create your views here.
def topicspanel(request):
    subjects = list(Subject.objects.all())
    context = {"subjects": subjects}
    return render(request, "appix/topicspanel.html", context)


# Create your views here.
def home(request):

    return render(request, "appix/home.html")


def questpanel(request, subject, pk):

    subject_id = Subject.objects.filter(subjectName=subject)[0].pk

    objs = list(SimpleCard.objects.filter(subject=subject_id))

    if pk < len(objs):

        obj = objs[pk]
    else:
        pk = 0
        obj = objs[0]

    form = MyAnswerForm(request.POST)

    if form.is_valid():

        newAnswer = form.cleaned_data["answer"]

        obj.answer = f"{newAnswer}"
        obj.save()

        return redirect(f"/questpanel/{obj.subject}/{pk+1}/")

    return render(request, "appix/questpanel.html", {"form": form, "quest": obj})
